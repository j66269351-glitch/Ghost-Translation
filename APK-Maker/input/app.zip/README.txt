Ghost Translation v4.0 - J Studio
1. Unzip and open index.html in Chrome (PC or phone).
2. To install as an app, upload the folder to any free host (GitHub Pages / Netlify) and use "Add to Home screen".
Voice input (mic) works in Google Chrome. Voice output uses the online Google voice and falls back to the device voice.
Files: index.html (app), icons/, manifest.json + sw.js (install/offline).
